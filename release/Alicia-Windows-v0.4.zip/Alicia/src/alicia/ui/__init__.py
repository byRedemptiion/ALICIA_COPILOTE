"""Interface de bureau Alicia."""
