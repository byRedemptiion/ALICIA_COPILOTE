"""Multimodal provider adapters."""
